<?php

return [
    'themes' => [
        'index',
        'install',
        'process'
    ]
];