<?php

return [
    'themes' => [
        'index',
        'install',
        'update',
        'process'
    ]
];